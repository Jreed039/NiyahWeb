import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('/users.json');

            if (!response.ok) {
                throw new Error('Failed to fetch users data');
            }

            const users = await response.json();

            const user = users.find(
                (u) =>
                    u.username === username &&
                    u.password === password
            );

            if (user) {
                // 🔥 SAVE USER PROPERLY (THIS FIXES EVERYTHING)
                localStorage.getItem(
                    'currentUser',
                    JSON.stringify({
                        username: user.username,
                        profile: user.profile || ''
                    })
                );

                setError('');
                alert('Login successful!');

                navigate('/Home');
            } else {
                setError('Invalid username or password.');
            }

        } catch (err) {
            console.error('Error fetching user data:', err);
            setError('There was an error with the login process.');
        }
    };

    return (
        <div className="login-container">

            <form className="login-form" onSubmit={handleLogin}>
                <h2>Login</h2>

                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />

                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />

                <button type="submit">Login</button>
            </form>

            {error && <p style={{ color: 'red' }}>{error}</p>}
        </div>
    );
};

export default Login;